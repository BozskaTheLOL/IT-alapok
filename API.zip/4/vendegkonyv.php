<style>
   
</style>
<?php
    $szam = rand(0, 100);
    $szam2= rand(0, 100);
    print"

<h2>Vendégkönyv</h2><br>
<form  action='vendegkonyv_ir.php' method='post' target='kisablak' enctype='multipart/form-data'>
Név:<br><input type='text' placeholder='Mi a Becses neved?' name='nev'/><br><br>
Megjegyzés:<br><textarea placeholder='Beep Boop?' name='megjegyzes'></textarea><br>
<br>
Jelölje be identitását!
<input type='radio' name='gombrobot' value='3'/>Robot <input type='radio' name='gombnemrobot' value='3'/>Nem robot
<br><br>$szam + $szam2 =<input type='text' name='ellenorzes' />
<input type='submit' value='bevitel'/><br><br>












</form>";
$fp = fopen("vendegkonyv.txt", 'r');
while($sor[] = fgets($fp)){};
$sor = array_reverse($sor);
foreach($sor as $adat) 
{
    print $adat;
}
fclose($fp);
$_SESSION['eredmeny'] =$szam +$szam2 ;
?>
<iframe name="kisablak" xheight="0" xwidth="0" xframeborder="0">