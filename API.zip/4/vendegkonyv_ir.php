<?php
session_start();
if ($_POST['nev'] =='')
{
    die("<script> alert('Add meg a neved lécci!')</script>");
}
if ($_POST['megjegyzes'] =='')
{
    die("<script> alert('Oszd meg mit gondolsz!')</script>");
}
if (isset($_POST['gombrobot']) || isset($_POST['gombnemrobot']))
{
    die("<script> alert('Te most tényleg robot vagy vagy nem megy a matek?')</script>");
}
/*if($_POST['ellenorzes'] != $_SESSION('eredmeny'))
{
    die('<script> alert("Te tényleg robot vagy."</script>');
}*/
if(!file_exists('vendegkonyv.txt'))
{
    $fp = fopen('vendegkonyv.txt', 'w');
    fclose($fp);
}
$uzenet = str_replace(';', ',', $_POST['megjegyzes']);
$uzenet = str_replace('\r\n', '<br>', $uzenet);
date_default_timezone_set("Europe/Budapest");
$beirando = date("Y-m-d H:i:s") . ";" . $_POST['nev'] . ";" . $uzenet . '\r\n';
$fp = fopen('vendegkonyv.txt', 'w');
fwrite($fp, $beirando);
fclose($fp);
print
    "
    <script>
        alert('Köszönjük hogy megosztottad gondolataid! Az adminunk pillanatokon belül ignorálni fogja')
        parent.location.href = parent.location.href
    </script>
    "
?>