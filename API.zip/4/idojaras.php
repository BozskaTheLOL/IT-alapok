<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="idojaras.css">
<title>Időjárás-előrejelzés</title>
</head>
<body>
<div id='fejlec'>
	<a href='/' title='napinap.hu'><img src='/napinap.ico' align='left'> <h1>Időjárás előrejelzés</h1></a>
    </div>

    <div id='terkepek'>
	<a href='/nyugat-dunantul/'    class='' ><img src='terkep/nyugat-dunantul.png'    title='Nyugat-Dunántúl'    ></a>
	<a href='/del-dunantul/'       class='' ><img src='terkep/del-dunantul.png'       title='Dél-Dunántúl'       ></a>
	<a href='/kozep-dunantul/'     class='' ><img src='terkep/kozep-dunantul.png'     title='Közép-Dunántúl'     ></a>
	<a href='/kozep-magyarorszag/' class='ez' ><img src='terkep/kozep-magyarorszag.png' title='Közép-Magyarország' ></a>
	<a href='/eszak-magyarorszag/' class='' ><img src='terkep/eszak-magyarorszag.png' title='Észak-Magyarország' ></a>
	<a href='/del-alfold/'         class='' ><img src='terkep/del-alfold.png'         title='Dél-Alföld'         ></a>
	<a href='/eszak-alfold/'       class='' ><img src='terkep/eszak-alfold.png'       title='Észak-Alföld'       ></a>
    </div>

	<div id='tartalom'>


    <h1>Budapest, Közép-Magyarország</h1>





		<div class='egynap'>

		    <p>Adatmegjelenítés időpontja: <b>&nbsp; ma 09:06</b></p>


		    <div class='napiadat'>

			<table align=center width=98% cellpadding=0 border=0>

			    <tr>
				<td title='dátum'        ><img src='/icon/calendar.png'  >                                              </td>
				<td title='napkelte'     ><img src='/icon/sunrise.png'   ><span>07:01</span></td>
				<td title='napnyugta'    ><img src='/icon/sunset.png'    ><span>16:55</span></td>
				<td title='nappal hossza'><img src='/icon/sunclock.png'  ><span>9 óra 54 perc</span></td>
			    </tr>


			    <tr>
				<td title='dátum'>
					<h2 style='margin:4px 0;'>Csütörtök</h2>
					február 8.
				</td>

				<td title='holdnyugta'><img src='/icon/moonset.png'   ><span>14:40</span></td>
				<td title='holdkelte' ><img src='/icon/moonrise.png'  ><span>06:34</span></td>
				<td title='holdfázis' ><img src='/icon/moonphase.png' ><span>6%  csökkenő</span></td>
			    </tr>

			</table>
</div>



<?php
		$fu   = fopen( "https://api.infojegyzet.hu/idojaras/" , "r" ) ;

		$json = "";
		while (!feof($fu))  $json .= fread($fu, 1024);

		fclose( $fu ) ;

		$adat = json_decode( $json ) ;

		
	?>

	<div style=' margin: 18px 0 18px 48px; font-family: Courier; color:#226;'>
		<pre><?php print_r($adat); ?></pre>
</body>
</html>
