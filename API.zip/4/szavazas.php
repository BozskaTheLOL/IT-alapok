<?php
 if (!isset($_SESSION['szavazott']))print "
<h2>Szavazás</h2>

<form action='szavazas_ir.php' method='post' target='kisablak'>
<input type='radio' name='0' value='1'/> Sima tej<br>
<input type='radio' name='0' value='2'/> Csokis tej <br>
<input type='radio' name='0' value='3'/> Kókusz tej <br>
<input type='radio' name='0' value='4'/> Kecske tej<br>
<input type='submit' value='Beküldés'/>
</form>

";

else
{
    $fp = fopen("szavazas.txt", "r");
    $sz = fread($fp, filesize("szavazas.txt"));
    fclose($fp);
    $eredmeny = count_chars($sz, 1);
    $ossz = array_sum($eredmeny);

    $a[1] = $eredmeny[49]/$ossz*100 . "px";
    $a[2] = $eredmeny[50]/$ossz*100 . "px";
    $a[3] = $eredmeny[51]/$ossz*100 . "px";
    $a[4] = $eredmeny[52]/$ossz*100 . "px";

    $s[1] = round($eredmeny[49]/$ossz*100) . "%";
    $s[2] = round($eredmeny[50]/$ossz*100) . "%";
    $s[3] = round($eredmeny[51]/$ossz*100) . "%";
    $s[4] = round($eredmeny[52]/$ossz*100) . "%";
    print "
    <style>
        cimke
        {
            display: inline-block;
            width: 120px;
        }
        bar
        {
            display: inline-block;
            height: 12px;
            background-color: #333;
        }
    </style>

    <br>
    <cimke> Sima tej: </cimke>$s[1]<bar style='width: $a[1]; '></bar> <br>
    <cimke> Csokis tej: </cimke>$s[2]<bar style='width:$a[2];'></bar> <br>
    <cimke> Kókusz tej: </cimke>$s[3]<bar style='width:$a[3];'></bar> <br>
    <cimke> Kecske tej: </cimke>$s[4]<bar style='width:$a[4];'></bar> <br>
    Köszönjük szavazatodat!
    ";
}

?>
<iframe name="kisablak" height="0" width="0" frameborder="0">