<?php

    session_start();

    //print_r($_POST);
    //print $_POST['0'];
    if (!isset($_POST['0']))
    {
        die("<script> alert('Nem felejtettél el valamit?')</script>");
    }
    if (!file_exists("szavazas.txt"))
    {
        $fp = fopen("szavazas.txt", "w");
        fclose ($fp);
    }

    $fp = fopen("szavazas.txt", "a");
    fwrite ($fp, $_POST['0']);    
    fclose($fp);

    $_SESSION['szavazott'] = "igen";
    print "
        <script>
        parent.location.href = parent.location.href 
        </script>";
?>