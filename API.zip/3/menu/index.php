<?php

	session_start();

?>
<!DOCTYPE html>
<html>

	<head>
	<link rel=stylesheet href="css.css">
	<link rel=stylesheet href="js.js">
	</head>
	<style>
	div#tartalom
	{
		margin 18px 36px;
		color #444		;
	}
	</style>
	
	
	<body>
	
	<header id="nav-wrapper">
    <nav id="nav" id='menu'>
      <div class="nav right">
		<a href='./?p=.' 			class="nav-link"			><span class="nav-link-span"><span class="u-nav"></span></span></a> 		|
        <a href='./' 			    class="nav-link active"		><span class="nav-link-span"><span class="u-nav">Kezdőlap</span></span></a> 	|
        <a href='./?p=elerhetoseg' 	class="nav-link"			><span class="nav-link-span"><span class="u-nav">Elérhetőség</span></span></a>  |
        <a href='./?p=vendegkonyv' 	class="nav-link"			><span class="nav-link-span"><span class="u-nav">Vendégkönyv</span></span></a> 	|
        <a href='./?p=szavazas' 	class="nav-link"			><span class="nav-link-span"><span class="u-nav">Szavazás</span></span></a> 	|
		<a href='./?p=galeria' 		class="nav-link"			><span class="nav-link-span"><span class="u-nav">Képgaléria</span></span></a> 	|
		<a href='./?p=kapcsolat' 	class="nav-link"			><span class="nav-link-span"><span class="u-nav">Kapcsolat</span></span></a> 	|
      </div>
    </nav>
  </header>
  <main>
  <div id='tartalom'>
	<?php
	 
	 if(isset($_GET['p']) ) $p=$_GET['p']	;
	 else					$p=""			;
	 
	 if( $p == "") print"<h2>Akciók, aktualitások</h2>"			;else
	 if( $p == "elerhetoseg") include("elerhetoseg.php")		;else
	 if( $p == "vendegkonyv") print"<h2>Vendégkönyv</h2>"		;else
	 if( $p == "szavazas") include("szavazas.php")				;else
	 if( $p == "galeria")print"<h2>Képgaléria</h2>"				;else
	 if( $p == "kapcsolat") print"<h2>Kapcsolat</h2>"			;else
							print"<h2>404 - A manóba</h2>"			;

	?>
	</div>

	</main>

	<?php	
			date_default_timezone_get();
			$fajlnev = date("Ymd").".txt";

			if (!file_exists($fajlnev))
			{
				$fp = fopen($fajlnev, "w");
				fwrite ($fp, "0");
				fclose ($fp);
			}

			$fp = fopen($fajlnev, "r");
			$n  =  fread ($fp, filesize($fajlnev));
				  fclose ($fp);
			
			if (!isset($_SESSION['magno']))
			{
				$_SESSION['magno'] = "ablak";
				$n++;
				$fp = fopen($fajlnev, "w");
				fwrite ($fp, $n);
				fclose ($fp);
			}
			
				print "<hr>Az oldalt eddig $n látogató látta";
				//print session_id();
			
	?>		
	</body>
	
 </html>